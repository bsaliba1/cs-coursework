package lab01;
public class BodyOfWater {
	private String name;
	public BodyOfWater(String aName) {
		name = aName;
	}
	public String getName() {
		return name;
	}
}

