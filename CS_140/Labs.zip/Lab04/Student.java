package Lab04;

import java.util.ArrayList;
import java.util.Arrays;

public class Student{
	private int id;
	private String name;

	public void setId(int x){
		id = x;
	}

	public void setName(String aName){
		name = aName;
	}
	public int getId(){
		return id;
	}
	public String getName(){
		return name;
	}
}