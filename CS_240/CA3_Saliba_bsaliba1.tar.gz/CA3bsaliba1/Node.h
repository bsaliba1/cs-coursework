#include <string>
class Node{
	string data;
	Node * next;

	Node();
	Node (string str);
	Node(Node* node);
}
