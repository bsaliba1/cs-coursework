# cs350Assignment5
Group Members:
Baptiste Saliba, Eddie Etheridge, Tyler Gabriel

How to run:
1. make
2. make files
3. ./main.exe
