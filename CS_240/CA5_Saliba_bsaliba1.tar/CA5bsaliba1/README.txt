For this program you will have to:
1) Feed in an input file to create the graph
2) Specify whether you want "Earliest", "Any", or "Exit" in the command line
	- Earliest will require a departure city, arrival city, a departure time, and a return time
	- Any will require a departure city and arrival city

*There is already an input file in the directory which I used to test

Some of the inputs that I tried and which worked were:
--------
Any a e
Any d e
Any b c
-------
Earliest a e 08:00am 03:00pm
Earliest b d 09:00am 09:59am
