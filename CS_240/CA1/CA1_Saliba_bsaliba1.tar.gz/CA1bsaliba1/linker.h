#include <string>
using namespace std;
void aNew(string* lastName,string* firstName,int* age,int* streetNumber,string* streetName,string* town,string* zipCode,float* donationAmount );
void update(string* lastName,string* firstName,int* age, int* streetNumber, string* streetName,string* town,string* zipCode);
void view(string* lastName, string* firstName,int* age, int* streetNumber, string* streetName,string* town,string* zipCode, float* donationAmount);
void donate(float* donationAmount);
void report(string* lastName, float* donationAmount);
