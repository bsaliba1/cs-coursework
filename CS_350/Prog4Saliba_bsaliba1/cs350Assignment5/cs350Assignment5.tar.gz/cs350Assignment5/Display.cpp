void Display(string LFS_FileName, int howMany, unsigned int start)
{
    /*Get the iNode number for the LFS File Name using the map in memory*/
    int iNodeNumber = file_map[LFS_FileName];

    /*Figure out which map the iNode information is in*/
    int mapNum = iNodeNumber / 256;

    int mapBlockNum = imap_find(mapNum);

    imap* im = getMap(mapBlockNum);

    /*Get the index into the iMap by taking the iNode number % 256*/
    int imapIndex = iNodeNumber % 256;

    int iNodeBlockNum = im->arr[iMapIndex];

    /*Get the iNode*/
    inode* in = getInode(iNodeBlockNum);
    
}
