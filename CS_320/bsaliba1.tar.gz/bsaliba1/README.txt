Name: Baptiste Saliba
BU-ID: bsaliba1
BNumber: B00599094
Other: I found it interesting how a small change to the initial state of the predictors(for example from strongly NT to weakly NT) can vastly change the number of correct branch predictions.
