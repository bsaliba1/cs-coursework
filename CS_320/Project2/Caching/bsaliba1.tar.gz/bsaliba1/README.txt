Baptiste Saliba
bsaliba1
B00599094

Extra Credit:
- For the extra credit I implemented a set associative cache that prefetches the next two lines on both hits and misses. I found that this made was better for 2 and 4 way set associative but not 8 and 16. I found this incredibly interesing because it would make sense that for less associativity you would have a better hit rate. 
- Testing: I commented out my extra credit(in order to make the grading algorithm work) in my main.cpp and made a comment where it is located. In order to test just simply remove the comments, use make command, then run the program. 

Additional Comments:
I found the hot cold bit replacement policy challenging yet cool to implement. Seeing the difference in complexity between LRU and hot cold replacement policy was funny seeing LRU is actually less accurate but was more difficult to program. All around I really enjoyed this progam.
