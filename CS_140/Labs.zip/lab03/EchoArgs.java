package lab03;

import java.util.Arrays;

/* YOUR ANSWERS HERE:
 * ------------------
 * 1.[]
 * 2.[hello]
 * 3.[hello, world]
 * 4.[hello world]
 * 5.[EchoArgs.java]
 */

public class EchoArgs {
    public static void main(String[] args) {
        System.out.println(Arrays.toString(args));
    }
}
