package Lab08;

import Lab08.Recursion;

public class Test {
	public static void main(String[]args) {
		System.out.println(Recursion.squareRoot(16));
		System.out.println(Recursion.squareRoot(0));
		System.out.println(Recursion.factorial(5));
		System.out.println(Recursion.sum( new int[] {1,2,3}));

		System.out.println(1e-6);
	}
}
